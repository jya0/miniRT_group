/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mlx_int_do_nothing.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pqueiroz <pqueiroz@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/29 00:37:34 ol                #+#    #+#             */
/*   Updated: 2020/01/29 00:37:36 by pqueiroz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
** Honestly, this function is very useful - Paulo Queiroz.
*/

int	mlx_int_do_nothing(void *param)
{
	(void)param;
	return (0);
}
